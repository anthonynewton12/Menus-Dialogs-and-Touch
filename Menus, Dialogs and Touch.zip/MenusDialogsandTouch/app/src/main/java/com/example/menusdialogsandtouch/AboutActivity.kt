package com.example.menusdialogsandtouch

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class AboutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        Log.v("About Activity", "Activity Started")
    }
}